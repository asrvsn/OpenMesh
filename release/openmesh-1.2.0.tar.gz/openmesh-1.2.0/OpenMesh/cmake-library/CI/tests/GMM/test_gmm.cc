#include <gmm/gmm.h>

int main(int argc, char *argv[])
{
    gmm::csc_matrix<double> mat;
    return 0;
}
